export interface PersonalInfo {
  fullName: string;
  email: string;
  phone: string;
  address: string;
  summary: string;
  website: string;
  linkedin: string;
}

export interface Education {
  id: string;
  institution: string;
  degree: string;
  field: string;
  startDate: string;
  endDate: string;
  description: string;
}

export interface Experience {
  id: string;
  company: string;
  position: string;
  startDate: string;
  endDate: string;
  description: string;
}

export interface Project {
  id: string;
  name: string;
  description: string;
  url: string;
}

export interface Certification {
  id: string;
  name: string;
  issuer: string;
  date: string;
}

export interface ResumeData {
  personalInfo: PersonalInfo;
  education: Education[];
  experience: Experience[];
  skills: string[];
  projects: Project[];
  certifications: Certification[];
}

export interface Resume {
  id: string;
  user_id: string;
  title: string;
  data: ResumeData;
  template: string;
  is_premium: boolean;
  created_at: string;
  updated_at: string;
}

export type TemplateId = 'classic' | 'modern' | 'executive';

export const defaultResumeData: ResumeData = {
  personalInfo: {
    fullName: '',
    email: '',
    phone: '',
    address: '',
    summary: '',
    website: '',
    linkedin: '',
  },
  education: [{ id: crypto.randomUUID(), institution: '', degree: '', field: '', startDate: '', endDate: '', description: '' }],
  experience: [{ id: crypto.randomUUID(), company: '', position: '', startDate: '', endDate: '', description: '' }],
  skills: [],
  projects: [],
  certifications: [],
};
