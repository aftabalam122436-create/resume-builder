import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useTheme } from '@/contexts/ThemeContext';
import SEO from '@/components/SEO';
import { FileText, Zap, Palette, Download, Shield, Clock, Moon, Sun, Check, ArrowRight, Star, ChevronDown, GraduationCap, Code, Briefcase, CreditCard as Edit, Eye, CloudDownload as DownloadCloud } from 'lucide-react';
import { useState } from 'react';

const features = [
  { icon: Zap, title: 'Lightning Fast', description: 'Build your resume in minutes with our intuitive editor and real-time preview.' },
  { icon: Palette, title: 'Professional Templates', description: 'Choose from beautifully designed templates that make you stand out.' },
  { icon: Download, title: 'PDF Export', description: 'Download your resume as a clean, print-ready PDF with one click.' },
  { icon: Shield, title: 'Secure Storage', description: 'Your data is safely stored and encrypted. Access your resumes anytime.' },
  { icon: Clock, title: 'Auto-Save', description: 'Never lose your work. Drafts are saved automatically as you type.' },
  { icon: FileText, title: 'ATS Friendly', description: 'Our templates are optimized to pass Applicant Tracking Systems.' },
];

const features_list = [
  'All resume templates included',
  'Cloud storage - save unlimited resumes',
  'Multiple resumes per account',
  'PDF download',
  'Auto-save draft feature',
  'Professional formatting',
  'ATS-optimized layouts',
  'Custom sections support',
];

const howItWorks = [
  { step: '1', icon: Edit, title: 'Fill In Your Details', desc: 'Enter your personal info, experience, education, and skills using our guided form.' },
  { step: '2', icon: Palette, title: 'Choose a Template', desc: 'Pick from our professionally designed, ATS-optimized resume templates.' },
  { step: '3', icon: Eye, title: 'Preview in Real Time', desc: 'See your resume update live as you type. Adjust formatting and content instantly.' },
  { step: '4', icon: DownloadCloud, title: 'Download as PDF', desc: 'Export your finished resume as a professional PDF ready to send to employers.' },
];

const useCases = [
  { icon: GraduationCap, title: 'Students & Freshers', desc: 'Create your first professional resume even without work experience. Highlight projects, coursework, and skills to land internships and entry-level positions.', link: '/blog/resume-tips-students' },
  { icon: Code, title: 'Developers & Tech', desc: 'Showcase your technical skills, projects, and GitHub contributions. Our templates are designed to highlight the qualifications tech companies look for.', link: '/blog/top-skills-developers-2026' },
  { icon: Briefcase, title: 'Experienced Professionals', desc: 'Present your career progression, leadership achievements, and quantified impact. Stand out with templates that convey authority and experience.', link: '/blog/how-to-write-experience-section' },
];

const faqs = [
  { q: 'Is Resume Builder Pro really free?', a: 'Yes, Resume Builder Pro is completely free with no hidden fees. All templates, features, and PDF downloads are included at no cost. We believe every job seeker deserves access to professional resume tools.' },
  { q: 'What makes a resume ATS-friendly?', a: 'ATS-friendly resumes use clean formatting, standard fonts, clear section headers, and relevant keywords from the job description. Our templates are specifically designed to pass through Applicant Tracking Systems successfully.' },
  { q: 'Can I create multiple resumes?', a: 'Yes, you can create and save unlimited resumes. This lets you tailor each resume for different job applications, which significantly improves your chances of getting interviews.' },
  { q: 'How do I download my resume as PDF?', a: 'Once you\'re satisfied with your resume, click the download button and your resume will be generated as a professional PDF file that preserves all formatting perfectly.' },
  { q: 'Is my data secure?', a: 'Absolutely. Your data is encrypted and stored securely using enterprise-grade infrastructure. We never share your personal information with third parties. You can delete your data at any time.' },
  { q: 'What resume templates are available?', a: 'We offer three professional templates: Classic (traditional serif layout), Modern (two-column design), and Executive (sidebar layout). All templates are ATS-optimized and free to use.' },
  { q: 'Can I edit my resume after saving?', a: 'Yes, all saved resumes can be edited at any time. Changes are auto-saved so you never lose your work. You can update your resume whenever you need to.' },
  { q: 'What should I include in my resume?', a: 'A strong resume includes your contact information, professional summary, work experience with quantified achievements, education, relevant skills, and any certifications. Check our blog for detailed guides on each section.' },
];

export default function LandingPage() {
  const { theme, toggleTheme } = useTheme();
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-background">
      <SEO
        title="Resume Builder Pro - Free Resume Maker Online"
        description="Create professional, ATS-friendly resumes for free with Resume Builder Pro. Choose from stunning templates, download as PDF instantly. No credit card required."
        keywords="resume builder, free resume maker, ATS resume, professional resume, resume templates, CV builder"
      />
      {/* Navbar */}
      <nav className="sticky top-0 z-50 border-b bg-background/80 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-lg bg-primary flex items-center justify-center">
              <FileText className="h-4 w-4 text-primary-foreground" />
            </div>
            <span className="font-bold text-lg">Resume Builder Pro</span>
          </Link>
          <div className="hidden md:flex items-center gap-4">
            <Link to="/templates" className="text-sm text-muted-foreground hover:text-foreground transition-colors">Templates</Link>
            <Link to="/blog" className="text-sm text-muted-foreground hover:text-foreground transition-colors">Blog</Link>
            <Link to="/about" className="text-sm text-muted-foreground hover:text-foreground transition-colors">About</Link>
          </div>
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" onClick={toggleTheme}>
              {theme === 'dark' ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            </Button>
            <Link to="/login"><Button variant="ghost" size="sm">Login</Button></Link>
            <Link to="/signup"><Button size="sm">Get Started</Button></Link>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-primary/5" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 sm:py-32 relative">
          <div className="text-center max-w-3xl mx-auto">
            <Badge variant="secondary" className="mb-4">
              <Star className="h-3 w-3 mr-1" /> Free Resume Builder - No Credit Card Required
            </Badge>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight mb-6">
              Build Your Perfect Resume{' '}
              <span className="text-primary">In Minutes</span>
            </h1>
            <p className="text-lg sm:text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              Create professional, ATS-friendly resumes with our free resume maker.
              Choose from stunning templates and download as PDF instantly. No signup fees, no hidden costs.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/signup">
                <Button size="lg" className="gap-2 text-base px-8">
                  Get Started Free <ArrowRight className="h-4 w-4" />
                </Button>
              </Link>
              <Link to="/demo">
                <Button size="lg" variant="outline" className="text-base px-8">
                  See Demo Resume
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">How It Works</h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">Create a professional resume in four simple steps. No design skills needed.</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {howItWorks.map((step) => (
              <div key={step.step} className="text-center">
                <div className="h-14 w-14 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4 relative">
                  <step.icon className="h-6 w-6 text-primary" />
                  <span className="absolute -top-1 -right-1 h-6 w-6 rounded-full bg-primary text-primary-foreground text-xs font-bold flex items-center justify-center">{step.step}</span>
                </div>
                <h3 className="font-semibold text-lg mb-2">{step.title}</h3>
                <p className="text-sm text-muted-foreground">{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">Everything You Need</h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              Powerful features designed to help you create the perfect resume effortlessly. Our free resume maker includes everything professionals need.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature) => (
              <Card key={feature.title} className="border-0 shadow-sm hover:shadow-md transition-shadow">
                <CardHeader>
                  <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center mb-2">
                    <feature.icon className="h-5 w-5 text-primary" />
                  </div>
                  <CardTitle className="text-lg">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-sm">{feature.description}</CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Resume Writing Tips */}
      <section className="py-20 border-b">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">Resume Writing Tips That Get Results</h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">Follow these proven strategies to create a resume that lands interviews.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {[
              { title: 'Use Action Verbs', desc: 'Start each bullet point with strong verbs like "Developed," "Managed," or "Increased" to convey impact and initiative.' },
              { title: 'Quantify Achievements', desc: 'Replace vague descriptions with numbers: "Increased sales by 25%" is far more compelling than "Helped improve sales."' },
              { title: 'Tailor for Each Job', desc: 'Customize your resume for every application by mirroring keywords and emphasizing the most relevant experience.' },
              { title: 'Keep It Concise', desc: 'Aim for one page. Recruiters spend an average of 6 seconds on initial resume review, so make every word count.' },
              { title: 'Optimize for ATS', desc: 'Use standard formatting, clear section headers, and relevant keywords to ensure your resume passes automated screening systems.' },
              { title: 'Proofread Thoroughly', desc: 'Even one typo can disqualify your application. Read your resume multiple times and ask someone else to review it.' },
            ].map(tip => (
              <Card key={tip.title} className="border-0 shadow-sm">
                <CardContent className="flex items-start gap-3 pt-5">
                  <Check className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                  <div>
                    <h3 className="font-semibold mb-1">{tip.title}</h3>
                    <p className="text-sm text-muted-foreground">{tip.desc}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
          <div className="text-center mt-8">
            <Link to="/blog"><Button variant="outline" className="gap-2">Read More Tips on Our Blog <ArrowRight className="h-4 w-4" /></Button></Link>
          </div>
        </div>
      </section>

      {/* Use Cases */}
      <section className="py-20 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">Built for Every Job Seeker</h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">Whether you're a student, developer, or seasoned professional, our free resume builder has you covered.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {useCases.map(uc => (
              <Card key={uc.title} className="hover:shadow-md transition-shadow">
                <CardHeader>
                  <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-3">
                    <uc.icon className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle className="text-lg">{uc.title}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-muted-foreground">{uc.desc}</p>
                  <Link to={uc.link}><Button variant="ghost" size="sm" className="gap-1.5 text-primary p-0">Read Guide <ArrowRight className="h-3.5 w-3.5" /></Button></Link>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section className="py-20">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">Completely Free, Forever</h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">No credit card required. All features included. The best free resume maker available online.</p>
          </div>
          <Card className="border-primary shadow-lg max-w-2xl mx-auto">
            <CardHeader className="text-center pb-6">
              <CardTitle className="text-3xl">Resume Builder Pro</CardTitle>
              <div className="mt-4">
                <span className="text-5xl font-bold">Free</span>
              </div>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3 mb-8">
                {features_list.map((f) => (
                  <li key={f} className="flex items-center gap-3 text-sm">
                    <Check className="h-5 w-5 text-primary shrink-0" />
                    <span className="text-base">{f}</span>
                  </li>
                ))}
              </ul>
              <Link to="/signup">
                <Button className="w-full" size="lg">
                  Get Started Free <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* FAQs */}
      <section className="py-20 bg-muted/30 border-t">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">Frequently Asked Questions</h2>
            <p className="text-muted-foreground text-lg">Everything you need to know about our free resume builder.</p>
          </div>
          <div className="space-y-3">
            {faqs.map((faq, i) => (
              <Card key={i} className="cursor-pointer" onClick={() => setOpenFaq(openFaq === i ? null : i)}>
                <CardContent className="py-4">
                  <div className="flex items-center justify-between gap-4">
                    <h3 className="font-semibold text-sm pr-4">{faq.q}</h3>
                    <ChevronDown className={`h-5 w-5 text-muted-foreground shrink-0 transition-transform ${openFaq === i ? 'rotate-180' : ''}`} />
                  </div>
                  {openFaq === i && (
                    <p className="text-sm text-muted-foreground mt-3 leading-relaxed">{faq.a}</p>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* SEO Content Section */}
      <section className="py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-2xl font-bold mb-4">The Best Free Resume Builder Online</h2>
          <div className="text-muted-foreground space-y-4 text-sm leading-relaxed">
            <p>
              Resume Builder Pro is the leading free resume maker designed to help job seekers create professional, ATS-optimized resumes in minutes. Unlike other resume builders that charge hidden fees or limit features, our platform provides all templates, cloud storage, and PDF export completely free.
            </p>
            <p>
              Whether you need a resume for your first job, a career change, or a senior leadership position, our free resume builder has the tools and templates to help you succeed. Our ATS resume templates are specifically designed to pass through Applicant Tracking Systems, ensuring your application reaches human recruiters.
            </p>
            <p>
              Creating a resume with our free resume maker is simple: fill in your information using our guided form, choose from our professionally designed templates, preview your resume in real-time, and download it as a PDF. The entire process takes just minutes, and the result is a polished, professional resume ready to impress employers.
            </p>
            <p>
              Our resume builder supports all standard resume sections including personal information, work experience, education, skills, projects, and certifications. Each section is fully customizable, allowing you to create a resume that perfectly presents your unique qualifications and achievements.
            </p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div className="col-span-2 md:col-span-1">
              <div className="flex items-center gap-2 mb-4">
                <div className="h-8 w-8 rounded-lg bg-primary flex items-center justify-center">
                  <FileText className="h-4 w-4 text-primary-foreground" />
                </div>
                <span className="font-bold text-lg">Resume Builder Pro</span>
              </div>
              <p className="text-muted-foreground text-sm max-w-xs">
                Create professional, ATS-friendly resumes for free. Trusted by thousands of job seekers worldwide.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-3 text-sm">Product</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><Link to="/templates" className="hover:text-foreground transition-colors">Templates</Link></li>
                <li><Link to="/demo" className="hover:text-foreground transition-colors">Resume Demo</Link></li>
                <li><Link to="/signup" className="hover:text-foreground transition-colors">Get Started</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-3 text-sm">Resources</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><Link to="/blog" className="hover:text-foreground transition-colors">Blog</Link></li>
                <li><Link to="/about" className="hover:text-foreground transition-colors">About Us</Link></li>
                <li><Link to="/contact" className="hover:text-foreground transition-colors">Contact</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-3 text-sm">Legal</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><Link to="/privacy" className="hover:text-foreground transition-colors">Privacy Policy</Link></li>
                <li><Link to="/terms" className="hover:text-foreground transition-colors">Terms & Conditions</Link></li>
              </ul>
            </div>
          </div>
          <div className="border-t mt-8 pt-8 flex flex-col sm:flex-row justify-between items-center gap-4 text-sm text-muted-foreground">
            <p>&copy; {new Date().getFullYear()} Resume Builder Pro. All rights reserved.</p>
            <a href="mailto:alamyasin718@gmail.com" className="hover:text-foreground transition-colors">alamyasin718@gmail.com</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
