import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import SEO from '@/components/SEO';

export default function PrivacyPage() {
  return (
    <div className="min-h-screen bg-background">
      <SEO title="Privacy Policy - Resume Builder Pro" description="Read our Privacy Policy to understand how Resume Builder Pro collects, uses, and protects your personal data. GDPR compliant." />
      <nav className="sticky top-0 z-40 border-b bg-card/80 backdrop-blur-sm">
        <div className="max-w-4xl mx-auto px-4 h-14 flex items-center justify-between">
          <Link to="/" className="font-bold text-lg">Resume Builder Pro</Link>
          <Link to="/"><Button variant="ghost" size="sm">Home</Button></Link>
        </div>
      </nav>
      <div className="max-w-4xl mx-auto px-4 py-12">
        <h1 className="text-3xl font-bold mb-2">Privacy Policy</h1>
        <p className="text-sm text-muted-foreground mb-8">Last updated: {new Date().toLocaleDateString()}</p>
        <div className="prose prose-sm dark:prose-invert max-w-none space-y-6 text-muted-foreground">

          <section>
            <h2 className="text-xl font-semibold text-foreground">1. Introduction</h2>
            <p>Resume Builder Pro ("we," "our," or "us") is committed to protecting your privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you use our website and services. Please read this policy carefully to understand our practices regarding your personal data.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground">2. Information We Collect</h2>
            <p>We collect information you provide directly when using our service, including:</p>
            <ul className="list-disc pl-6 space-y-1">
              <li><strong>Account Information:</strong> Name, email address, and password when you create an account</li>
              <li><strong>Resume Data:</strong> All information you enter into your resumes (personal details, work experience, education, skills, etc.)</li>
              <li><strong>Usage Data:</strong> How you interact with our service, pages visited, features used, and time spent</li>
              <li><strong>Device Information:</strong> Browser type, operating system, IP address, and device identifiers</li>
              <li><strong>Preferences:</strong> Theme preferences, template selections, and other settings</li>
            </ul>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground">3. How We Use Your Information</h2>
            <p>We use the information we collect to:</p>
            <ul className="list-disc pl-6 space-y-1">
              <li>Provide, maintain, and improve our resume building services</li>
              <li>Save and sync your resume data across sessions</li>
              <li>Communicate important updates about your account or our service</li>
              <li>Analyze usage patterns to improve user experience and service quality</li>
              <li>Ensure the security and integrity of our platform</li>
              <li>Comply with legal obligations</li>
            </ul>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground">4. Data Storage and Security</h2>
            <p>Your data is stored securely using <strong>Supabase</strong>, which provides enterprise-grade infrastructure hosted on Amazon Web Services (AWS). Supabase implements:</p>
            <ul className="list-disc pl-6 space-y-1">
              <li>Encryption at rest using AES-256</li>
              <li>Encryption in transit using TLS 1.2+</li>
              <li>Row Level Security (RLS) to ensure data isolation between users</li>
              <li>Regular security audits and compliance certifications</li>
            </ul>
            <p>Resume data is only accessible to you through your authenticated account. We do not access your resume content unless required for technical support or legal compliance.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground">5. Cookies and Tracking Technologies</h2>
            <p>We use cookies and similar tracking technologies for the following purposes:</p>
            <ul className="list-disc pl-6 space-y-1">
              <li><strong>Essential Cookies:</strong> Required for authentication and basic site functionality</li>
              <li><strong>Functional Cookies:</strong> Remember your preferences (theme, settings)</li>
              <li><strong>Analytics Cookies:</strong> Help us understand how visitors interact with our website</li>
              <li><strong>Advertising Cookies:</strong> Used by Google AdSense to display relevant advertisements</li>
            </ul>
            <p>You can manage your cookie preferences through your browser settings. Disabling certain cookies may affect site functionality.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground">6. Google AdSense and Advertising</h2>
            <p>We use Google AdSense to display advertisements on our website. Google AdSense may use cookies and web beacons to serve ads based on your prior visits to our website or other websites. Google's use of advertising cookies enables it and its partners to serve ads based on your visit to our site and/or other sites on the Internet.</p>
            <p>You may opt out of personalized advertising by visiting <a href="https://www.google.com/settings/ads" className="text-primary hover:underline" target="_blank" rel="noopener noreferrer">Google Ads Settings</a>. For more information about how Google uses data, please review <a href="https://policies.google.com/privacy" className="text-primary hover:underline" target="_blank" rel="noopener noreferrer">Google's Privacy Policy</a>.</p>
            <p>Third-party vendors, including Google, may use cookies to serve ads based on a user's prior visits to this website or other websites. This use of cookies for ad personalization is governed by Google's policies and applicable regulations.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground">7. Third-Party Services</h2>
            <p>We integrate with the following third-party services:</p>
            <ul className="list-disc pl-6 space-y-1">
              <li><strong>Supabase:</strong> Database, authentication, and storage services</li>
              <li><strong>Google AdSense:</strong> Advertising platform</li>
              <li><strong>Google Analytics:</strong> Website analytics (if implemented)</li>
            </ul>
            <p>These services have their own privacy policies governing the use of your information. We encourage you to review their policies when using these services.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground">8. GDPR Compliance (EU Users)</h2>
            <p>For users in the European Economic Area (EEA), we comply with the General Data Protection Regulation (GDPR). Under GDPR, you have the following rights:</p>
            <ul className="list-disc pl-6 space-y-1">
              <li><strong>Right to Access:</strong> Request a copy of your personal data</li>
              <li><strong>Right to Rectification:</strong> Request correction of inaccurate data</li>
              <li><strong>Right to Erasure:</strong> Request deletion of your personal data ("Right to be Forgotten")</li>
              <li><strong>Right to Data Portability:</strong> Receive your data in a portable format</li>
              <li><strong>Right to Restrict Processing:</strong> Limit how we process your data</li>
              <li><strong>Right to Object:</strong> Object to processing based on legitimate interests</li>
              <li><strong>Right to Withdraw Consent:</strong> Withdraw consent at any time where processing is based on consent</li>
            </ul>
            <p>To exercise any of these rights, contact us at <a href="mailto:alamyasin718@gmail.com" className="text-primary hover:underline">alamyasin718@gmail.com</a>. We will respond to your request within 30 days.</p>
            <p>We process your data based on: (a) your consent, (b) the necessity for performance of a contract, (c) compliance with legal obligations, and (d) our legitimate interests.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground">9. Data Retention</h2>
            <p>We retain your personal data as long as your account is active or as needed to provide our services. If you delete your account, we will delete your personal data within 30 days, except where retention is required by law. Resume data is retained until you delete it or your account.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground">10. Children's Privacy</h2>
            <p>Our service is not directed to children under the age of 16. We do not knowingly collect personal information from children under 16. If we discover that a child under 16 has provided us with personal data, we will delete such information promptly.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground">11. Data Breach Notification</h2>
            <p>In the event of a data breach that may affect your personal data, we will notify you and the relevant supervisory authority within 72 hours as required by GDPR, unless the breach is unlikely to result in a risk to your rights and freedoms.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground">12. International Data Transfers</h2>
            <p>Your data may be transferred to and processed in countries outside your jurisdiction. We ensure appropriate safeguards are in place, including standard contractual clauses approved by the European Commission, to protect your data during international transfers.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground">13. Changes to This Policy</h2>
            <p>We may update this Privacy Policy from time to time. We will notify you of any material changes by posting the new policy on this page and updating the "Last updated" date. Your continued use of our service after changes constitutes acceptance of the updated policy.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground">14. Contact Us</h2>
            <p>If you have any questions or concerns about this Privacy Policy or our data practices, please contact us at:</p>
            <p>Email: <a href="mailto:alamyasin718@gmail.com" className="text-primary hover:underline">alamyasin718@gmail.com</a></p>
            <p>Contact Page: <Link to="/contact" className="text-primary hover:underline">Contact Us</Link></p>
          </section>
        </div>
      </div>
    </div>
  );
}
