import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useResume } from '@/contexts/ResumeContext';
import { supabase } from '@/lib/supabase';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { toast } from '@/hooks/use-toast';
import { CirclePlus as PlusCircle, FileText, Trash2, CreditCard as Edit, Clock, Loader as Loader2 } from 'lucide-react';
import type { ResumeData, TemplateId } from '@/types/resume';

interface SavedResume {
  id: string;
  title: string;
  data: ResumeData;
  template: string;
  created_at: string;
  updated_at: string;
}

export default function MyResumesPage() {
  const { user } = useAuth();
  const { loadResume } = useResume();
  const navigate = useNavigate();
  const [resumes, setResumes] = useState<SavedResume[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchResumes = useCallback(async () => {
    if (!user) return;
    try {
      const { data } = await supabase
        .from('resumes')
        .select('*')
        .eq('user_id', user.id)
        .order('updated_at', { ascending: false });
      if (data) {
        setResumes(data as SavedResume[]);
      }
    } catch {
      // Fallback to localStorage
      const local = localStorage.getItem('saved-resumes');
      if (local) {
        setResumes(JSON.parse(local));
      }
    }
    setLoading(false);
  }, [user]);

  useEffect(() => {
    fetchResumes();
  }, [fetchResumes]);

  const handleEdit = (resume: SavedResume) => {
    loadResume(resume.data, resume.template as TemplateId, resume.title);
    navigate('/dashboard/create');
  };

  const handleDelete = async (id: string) => {
    try {
      if (user) {
        await supabase.from('resumes').delete().eq('id', id);
      }
      setResumes(prev => prev.filter(r => r.id !== id));
      toast({ title: 'Resume deleted' });
    } catch {
      toast({ title: 'Failed to delete resume', variant: 'destructive' });
    }
  };

  const handleCreateNew = () => {
    loadResume(
      {
        personalInfo: { fullName: '', email: '', phone: '', address: '', summary: '', website: '', linkedin: '' },
        education: [{ id: crypto.randomUUID(), institution: '', degree: '', field: '', startDate: '', endDate: '', description: '' }],
        experience: [{ id: crypto.randomUUID(), company: '', position: '', startDate: '', endDate: '', description: '' }],
        skills: [],
        projects: [],
        certifications: [],
      },
      'classic',
      'Untitled Resume'
    );
    navigate('/dashboard/create');
  };

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-2xl font-bold">My Resumes</h2>
          <p className="text-muted-foreground mt-1">Manage your saved resumes</p>
        </div>
        <Button onClick={handleCreateNew} className="gap-1.5">
          <PlusCircle className="h-4 w-4" /> New Resume
        </Button>
      </div>

      {loading ? (
        <div className="flex justify-center py-12">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </div>
      ) : resumes.length === 0 ? (
        <Card className="text-center py-12">
          <CardContent>
            <FileText className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">No resumes yet</h3>
            <p className="text-muted-foreground mb-4">Create your first resume to get started</p>
            <Button onClick={handleCreateNew} className="gap-1.5">
              <PlusCircle className="h-4 w-4" /> Create Resume
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {resumes.map((resume) => (
            <Card key={resume.id} className="hover:shadow-md transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <CardTitle className="text-base truncate pr-2">{resume.title}</CardTitle>
                  <Badge variant="secondary" className="shrink-0 capitalize text-xs">
                    {resume.template}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-1.5 text-xs text-muted-foreground mb-4">
                  <Clock className="h-3 w-3" />
                  {new Date(resume.updated_at || resume.created_at).toLocaleDateString()}
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" className="flex-1 gap-1.5" onClick={() => handleEdit(resume)}>
                    <Edit className="h-3.5 w-3.5" /> Edit
                  </Button>
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button variant="outline" size="sm" className="text-destructive hover:text-destructive">
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Delete Resume</AlertDialogTitle>
                        <AlertDialogDescription>
                          This action cannot be undone. This will permanently delete your resume "{resume.title}".
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction onClick={() => handleDelete(resume.id)} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                          Delete
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
