import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { FileText, Users, Shield, Heart, Globe, ArrowRight } from 'lucide-react';
import SEO from '@/components/SEO';

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-background">
      <SEO title="About Us - Resume Builder Pro" description="Learn about Resume Builder Pro - our mission to provide free, professional resume building tools for every job seeker." />
      <nav className="sticky top-0 z-40 border-b bg-card/80 backdrop-blur-sm">
        <div className="max-w-6xl mx-auto px-4 h-14 flex items-center justify-between">
          <Link to="/" className="font-bold text-lg">Resume Builder Pro</Link>
          <Link to="/"><Button variant="ghost" size="sm">Home</Button></Link>
        </div>
      </nav>

      <section className="bg-gradient-to-br from-primary/10 via-transparent to-primary/5 py-20 border-b">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <Badge className="mb-4">About Us</Badge>
          <h1 className="text-4xl sm:text-5xl font-bold mb-6">Building Better Careers,<br />One Resume at a Time</h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Resume Builder Pro is a free, professional resume creation tool designed to help job seekers
            craft ATS-optimized resumes that land interviews and get hired.
          </p>
        </div>
      </section>

      <section className="py-16">
        <div className="max-w-5xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mb-16">
            <div>
              <h2 className="text-2xl font-bold mb-4">Our Mission</h2>
              <p className="text-muted-foreground mb-4">
                We believe every job seeker deserves access to professional resume-building tools,
                regardless of their budget. Our mission is to democratize career preparation by offering
                a completely free, feature-rich resume builder that produces results comparable to paid services.
              </p>
              <p className="text-muted-foreground">
                Traditional resume writing services can cost hundreds of dollars, putting them out of reach
                for many job seekers. Resume Builder Pro changes that by providing professionally designed
                templates, ATS-optimized formatting, and an intuitive editor completely free.
              </p>
            </div>
            <div>
              <h2 className="text-2xl font-bold mb-4">Who We Serve</h2>
              <p className="text-muted-foreground mb-4">
                Our platform serves a diverse community of job seekers: students entering the workforce
                for the first time, experienced professionals advancing their careers, career changers
                pivoting to new industries, and anyone who needs a professional resume.
              </p>
              <p className="text-muted-foreground">
                Whether you're applying for your first internship or a C-suite position, Resume Builder Pro
                provides the tools and templates to present your qualifications effectively.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
            {[
              { icon: FileText, title: 'Professional Templates', desc: 'Beautifully designed, ATS-friendly resume templates for every industry and career stage.' },
              { icon: Users, title: 'User-First Design', desc: 'Intuitive interface that makes resume creation simple and efficient for everyone.' },
              { icon: Shield, title: 'Secure & Private', desc: 'Your data is encrypted and stored securely. We never share your personal information.' },
              { icon: Heart, title: 'Completely Free', desc: 'All features, all templates, no hidden fees. Free today and free forever.' },
              { icon: Globe, title: 'Global Community', desc: 'Trusted by thousands of job seekers across the world to create professional resumes.' },
              { icon: ArrowRight, title: 'ATS Optimized', desc: 'Templates and formatting designed to pass Applicant Tracking Systems successfully.' },
            ].map(item => (
              <Card key={item.title} className="border-0 shadow-sm">
                <CardHeader>
                  <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center mb-2">
                    <item.icon className="h-5 w-5 text-primary" />
                  </div>
                  <CardTitle className="text-base">{item.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground">{item.desc}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="text-center bg-muted/50 rounded-xl p-8">
            <h2 className="text-2xl font-bold mb-3">Ready to Get Started?</h2>
            <p className="text-muted-foreground mb-6 max-w-lg mx-auto">
              Join thousands of professionals who've used Resume Builder Pro to create resumes that get results.
            </p>
            <Link to="/signup"><Button size="lg" className="gap-2">Create Your Resume <ArrowRight className="h-4 w-4" /></Button></Link>
          </div>
        </div>
      </section>
    </div>
  );
}
