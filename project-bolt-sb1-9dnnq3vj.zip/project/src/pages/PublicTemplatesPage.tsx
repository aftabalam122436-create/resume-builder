import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Check, ArrowRight, FileText } from 'lucide-react';
import type { TemplateId } from '@/types/resume';
import SEO from '@/components/SEO';

interface TemplateInfo {
  id: TemplateId;
  name: string;
  description: string;
  features: string[];
}

const templates: TemplateInfo[] = [
  { id: 'classic', name: 'Classic', description: 'Traditional serif layout, clean and professional. Perfect for corporate roles, finance, and legal industries.', features: ['Single column layout', 'Traditional typography', 'ATS-optimized', 'Corporate-friendly'] },
  { id: 'modern', name: 'Modern', description: 'Two-column design with timeline accents. Great for tech, creative fields, and startups.', features: ['Two-column layout', 'Modern typography', 'Skills sidebar', 'Tech-industry ready'] },
  { id: 'executive', name: 'Executive', description: 'Dark sidebar with accents. Ideal for senior leadership, management, and executive positions.', features: ['Sidebar layout', 'Executive styling', 'Leadership focus', 'Premium appearance'] },
];

export default function PublicTemplatesPage() {
  return (
    <div className="min-h-screen bg-background">
      <SEO title="Resume Templates - Resume Builder Pro" description="Browse our collection of free, ATS-optimized resume templates. Classic, Modern, and Executive designs available at no cost." keywords="resume templates, free resume templates, ATS templates, professional resume templates" />
      <nav className="sticky top-0 z-40 border-b bg-card/80 backdrop-blur-sm">
        <div className="max-w-6xl mx-auto px-4 h-14 flex items-center justify-between">
          <Link to="/" className="font-bold text-lg">Resume Builder Pro</Link>
          <Link to="/"><Button variant="ghost" size="sm">Home</Button></Link>
        </div>
      </nav>

      <section className="bg-gradient-to-br from-primary/10 via-transparent to-primary/5 py-16 border-b">
        <div className="max-w-6xl mx-auto px-4 text-center">
          <Badge className="mb-4">All Free</Badge>
          <h1 className="text-4xl sm:text-5xl font-bold mb-4">Professional Resume Templates</h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Choose from our collection of ATS-optimized, professionally designed templates. All templates are completely free to use.
          </p>
        </div>
      </section>

      <section className="py-16">
        <div className="max-w-6xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {templates.map((template) => (
              <Card key={template.id} className="hover:shadow-lg transition-shadow">
                {/* Preview */}
                <div className="aspect-[3/4] bg-muted/50 border-b flex items-center justify-center overflow-hidden">
                  {template.id === 'classic' && (
                    <div className="w-[80%] h-[85%] bg-white shadow-sm p-3" style={{ fontSize: '4px' }}>
                      <div className="text-center border-b border-gray-300 pb-1 mb-1">
                        <div className="font-bold" style={{ fontSize: '7px' }}>John Doe</div>
                        <div className="text-gray-500" style={{ fontSize: '3px' }}>john@email.com | +1 555-0000</div>
                      </div>
                      <div className="border-b border-gray-200 pb-0.5 mb-1">
                        <div className="font-bold uppercase" style={{ fontSize: '4px' }}>Summary</div>
                        <div className="text-gray-400" style={{ fontSize: '3px' }}>Professional summary...</div>
                      </div>
                      <div className="border-b border-gray-200 pb-0.5 mb-1">
                        <div className="font-bold uppercase" style={{ fontSize: '4px' }}>Experience</div>
                        <div className="font-semibold" style={{ fontSize: '3.5px' }}>Software Engineer</div>
                        <div className="text-gray-400" style={{ fontSize: '3px' }}>Company Name</div>
                      </div>
                      <div>
                        <div className="font-bold uppercase" style={{ fontSize: '4px' }}>Education</div>
                        <div className="font-semibold" style={{ fontSize: '3.5px' }}>B.S. Computer Science</div>
                      </div>
                    </div>
                  )}
                  {template.id === 'modern' && (
                    <div className="w-[80%] h-[85%] bg-white shadow-sm overflow-hidden" style={{ fontSize: '4px' }}>
                      <div className="bg-slate-800 text-white p-3">
                        <div className="font-light" style={{ fontSize: '7px' }}>John Doe</div>
                        <div className="text-slate-300" style={{ fontSize: '3px' }}>john@email.com</div>
                      </div>
                      <div className="p-3 grid grid-cols-3 gap-2">
                        <div className="col-span-2">
                          <div className="font-bold uppercase" style={{ fontSize: '4px' }}>Experience</div>
                          <div className="pl-2 border-l border-slate-200 mt-1">
                            <div className="font-semibold" style={{ fontSize: '3.5px' }}>Software Engineer</div>
                          </div>
                        </div>
                        <div className="col-span-1">
                          <div className="font-bold uppercase" style={{ fontSize: '4px' }}>Skills</div>
                          <div className="flex flex-wrap gap-0.5 mt-1">
                            <span className="bg-slate-100 px-1 rounded" style={{ fontSize: '3px' }}>React</span>
                            <span className="bg-slate-100 px-1 rounded" style={{ fontSize: '3px' }}>TS</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                  {template.id === 'executive' && (
                    <div className="w-[80%] h-[85%] bg-white shadow-sm overflow-hidden grid grid-cols-3" style={{ fontSize: '4px' }}>
                      <div className="col-span-1 bg-gray-900 text-white p-2">
                        <div className="font-bold" style={{ fontSize: '6px' }}>John Doe</div>
                        <div className="text-gray-400 mt-2" style={{ fontSize: '3px' }}>Contact</div>
                        <div className="text-gray-300" style={{ fontSize: '3px' }}>john@email.com</div>
                        <div className="text-gray-400 mt-2" style={{ fontSize: '3px' }}>Skills</div>
                      </div>
                      <div className="col-span-2 p-2">
                        <div className="font-bold uppercase border-b-2 border-amber-500 pb-0.5 inline-block" style={{ fontSize: '4px' }}>Summary</div>
                        <div className="text-gray-400 mt-1" style={{ fontSize: '3px' }}>Professional summary...</div>
                        <div className="font-bold uppercase border-b-2 border-amber-500 pb-0.5 inline-block mt-2" style={{ fontSize: '4px' }}>Experience</div>
                      </div>
                    </div>
                  )}
                </div>

                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">{template.name}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-muted-foreground">{template.description}</p>
                  <ul className="space-y-1.5">
                    {template.features.map(f => (
                      <li key={f} className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Check className="h-3.5 w-3.5 text-primary shrink-0" /> {f}
                      </li>
                    ))}
                  </ul>
                  <Link to="/signup">
                    <Button className="w-full gap-2">Use This Template <ArrowRight className="h-4 w-4" /></Button>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-muted/50 border-t py-12">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <FileText className="h-10 w-10 mx-auto text-primary mb-4" />
          <h2 className="text-2xl font-bold mb-3">See a Live Resume Demo</h2>
          <p className="text-muted-foreground mb-6">Preview how your completed resume will look before signing up.</p>
          <Link to="/demo"><Button variant="outline" size="lg">View Resume Demo</Button></Link>
        </div>
      </section>
    </div>
  );
}
