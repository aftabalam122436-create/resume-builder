import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { ArrowLeft, ArrowRight } from 'lucide-react';
import SEO from '@/components/SEO';

export default function ResumeDemoPage() {
  return (
    <div className="min-h-screen bg-background">
      <SEO title="Sample Resume Preview - Resume Builder Pro" description="Preview how your completed resume will look. See a live demo of our Classic template with sample content." />
      <nav className="sticky top-0 z-40 border-b bg-card/80 backdrop-blur-sm">
        <div className="max-w-6xl mx-auto px-4 h-14 flex items-center justify-between">
          <Link to="/" className="font-bold text-lg">Resume Builder Pro</Link>
          <div className="flex items-center gap-2">
            <Link to="/templates"><Button variant="ghost" size="sm">Templates</Button></Link>
            <Link to="/signup"><Button size="sm">Get Started</Button></Link>
          </div>
        </div>
      </nav>

      <div className="max-w-5xl mx-auto px-4 py-12">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold mb-2">Sample Resume Preview</h1>
          <p className="text-muted-foreground">This is a demo of what your resume will look like when built with our Classic template.</p>
        </div>

        <div className="flex justify-center mb-8">
          <div className="bg-white text-black shadow-xl border" style={{ width: '612px', minHeight: '792px', padding: '40px', fontSize: '11px', lineHeight: '1.5', fontFamily: 'Georgia, serif' }}>
            <div style={{ textAlign: 'center', borderBottom: '2px solid #1a1a1a', paddingBottom: '10px', marginBottom: '16px' }}>
              <div style={{ fontSize: '24px', fontWeight: 'bold', letterSpacing: '1px' }}>SARAH JOHNSON</div>
              <div style={{ fontSize: '11px', color: '#555', marginTop: '4px' }}>sarah.johnson@email.com | +1 (555) 234-5678 | San Francisco, CA | linkedin.com/in/sarahjohnson</div>
            </div>

            <div style={{ marginBottom: '14px' }}>
              <div style={{ fontSize: '13px', fontWeight: 'bold', textTransform: 'uppercase', borderBottom: '1px solid #ccc', paddingBottom: '3px', marginBottom: '6px' }}>Professional Summary</div>
              <div style={{ color: '#333' }}>Results-driven Software Engineer with 5+ years of experience building scalable web applications. Proven track record of delivering high-quality solutions using React, Node.js, and cloud technologies. Passionate about clean code, mentorship, and driving business impact through technology.</div>
            </div>

            <div style={{ marginBottom: '14px' }}>
              <div style={{ fontSize: '13px', fontWeight: 'bold', textTransform: 'uppercase', borderBottom: '1px solid #ccc', paddingBottom: '3px', marginBottom: '6px' }}>Work Experience</div>

              <div style={{ marginBottom: '10px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <strong>Senior Software Engineer</strong>
                  <span style={{ color: '#555' }}>Jan 2022 - Present</span>
                </div>
                <div style={{ color: '#555', fontStyle: 'italic' }}>Tech Innovations Inc., San Francisco, CA</div>
                <ul style={{ paddingLeft: '16px', marginTop: '4px', color: '#333' }}>
                  <li>Architected and deployed 12+ production web applications serving 50,000+ daily active users</li>
                  <li>Optimized database queries reducing API response times by 40%</li>
                  <li>Mentored 4 junior developers through code reviews and technical training</li>
                  <li>Led cross-functional team implementing microservices architecture, enabling 30% faster deployments</li>
                </ul>
              </div>

              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <strong>Software Engineer</strong>
                  <span style={{ color: '#555' }}>Jun 2018 - Dec 2021</span>
                </div>
                <div style={{ color: '#555', fontStyle: 'italic' }}>Digital Solutions LLC, San Francisco, CA</div>
                <ul style={{ paddingLeft: '16px', marginTop: '4px', color: '#333' }}>
                  <li>Built responsive web interfaces using React and Tailwind CSS</li>
                  <li>Designed RESTful APIs serving 10,000+ daily users with 99.9% uptime</li>
                  <li>Implemented CI/CD pipelines reducing deployment time by 50%</li>
                </ul>
              </div>
            </div>

            <div style={{ marginBottom: '14px' }}>
              <div style={{ fontSize: '13px', fontWeight: 'bold', textTransform: 'uppercase', borderBottom: '1px solid #ccc', paddingBottom: '3px', marginBottom: '6px' }}>Education</div>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <strong>Bachelor of Science in Computer Science</strong>
                <span style={{ color: '#555' }}>May 2018</span>
              </div>
              <div style={{ color: '#555', fontStyle: 'italic' }}>University of California, Berkeley | GPA: 3.7/4.0</div>
            </div>

            <div style={{ marginBottom: '14px' }}>
              <div style={{ fontSize: '13px', fontWeight: 'bold', textTransform: 'uppercase', borderBottom: '1px solid #ccc', paddingBottom: '3px', marginBottom: '6px' }}>Skills</div>
              <div style={{ color: '#333' }}>
                <strong>Languages:</strong> Python, JavaScript, TypeScript, SQL &nbsp;|&nbsp;
                <strong>Frontend:</strong> React, HTML5, CSS3, Tailwind &nbsp;|&nbsp;
                <strong>Backend:</strong> Node.js, Express, REST APIs &nbsp;|&nbsp;
                <strong>Tools:</strong> Git, Docker, AWS, PostgreSQL
              </div>
            </div>

            <div>
              <div style={{ fontSize: '13px', fontWeight: 'bold', textTransform: 'uppercase', borderBottom: '1px solid #ccc', paddingBottom: '3px', marginBottom: '6px' }}>Certifications</div>
              <ul style={{ paddingLeft: '16px', color: '#333' }}>
                <li>AWS Certified Solutions Architect - Associate (2023)</li>
                <li>Google Cloud Professional Data Engineer (2022)</li>
              </ul>
            </div>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row justify-center gap-4">
          <Link to="/templates"><Button variant="outline" size="lg" className="gap-2"><ArrowLeft className="h-4 w-4" /> View All Templates</Button></Link>
          <Link to="/signup"><Button size="lg" className="gap-2">Build Your Resume Free <ArrowRight className="h-4 w-4" /></Button></Link>
        </div>

        <Card className="mt-12 bg-muted/50">
          <CardContent className="py-8 text-center">
            <h3 className="text-xl font-bold mb-2">This Demo Uses Our Classic Template</h3>
            <p className="text-muted-foreground mb-4">We also offer Modern and Executive templates - all free. Sign up to try them all.</p>
            <Link to="/signup"><Button>Create Your Resume</Button></Link>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
