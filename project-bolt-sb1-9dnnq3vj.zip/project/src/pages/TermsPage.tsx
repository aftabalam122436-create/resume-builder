import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import SEO from '@/components/SEO';

export default function TermsPage() {
  return (
    <div className="min-h-screen bg-background">
      <SEO title="Terms & Conditions - Resume Builder Pro" description="Read the Terms & Conditions for using Resume Builder Pro. Understand your rights and responsibilities when using our free resume builder." />
      <nav className="sticky top-0 z-40 border-b bg-card/80 backdrop-blur-sm">
        <div className="max-w-4xl mx-auto px-4 h-14 flex items-center justify-between">
          <Link to="/" className="font-bold text-lg">Resume Builder Pro</Link>
          <Link to="/"><Button variant="ghost" size="sm">Home</Button></Link>
        </div>
      </nav>
      <div className="max-w-4xl mx-auto px-4 py-12">
        <h1 className="text-3xl font-bold mb-2">Terms & Conditions</h1>
        <p className="text-sm text-muted-foreground mb-8">Last updated: {new Date().toLocaleDateString()}</p>
        <div className="prose prose-sm dark:prose-invert max-w-none space-y-6 text-muted-foreground">

          <section>
            <h2 className="text-xl font-semibold text-foreground">1. Acceptance of Terms</h2>
            <p>By accessing and using Resume Builder Pro ("the Service"), you agree to be bound by these Terms & Conditions ("Terms"). If you do not agree to these Terms, please do not use our Service. These Terms apply to all visitors, users, and others who access or use the Service.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground">2. Description of Service</h2>
            <p>Resume Builder Pro provides a free, web-based tool for creating, editing, saving, and downloading professional resumes. The Service includes resume templates, a guided form editor, real-time preview, PDF export, and cloud storage for saved resumes. All features are provided at no cost.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground">3. User Accounts</h2>
            <p>You must create an account to save resumes and access dashboard features. When creating an account, you agree to:</p>
            <ul className="list-disc pl-6 space-y-1">
              <li>Provide accurate, current, and complete information</li>
              <li>Maintain and promptly update your account information</li>
              <li>Maintain the security and confidentiality of your login credentials</li>
              <li>Accept responsibility for all activities that occur under your account</li>
              <li>Notify us immediately of any unauthorized use of your account</li>
            </ul>
            <p>You must be at least 16 years of age to create an account and use our Service.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground">4. Account Responsibility</h2>
            <p>You are solely responsible for maintaining the confidentiality of your account and password. You agree to accept responsibility for all activities that occur under your account. You must immediately notify Resume Builder Pro of any unauthorized use of your account or any other breach of security. Resume Builder Pro will not be liable for any loss or damage arising from your failure to comply with this section.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground">5. User Content</h2>
            <p>You retain ownership of all resume content you create using our Service. By using our Service, you grant us a limited, non-exclusive license to store, process, and display your content solely for the purpose of providing the Service to you. This license terminates when you delete your content or your account.</p>
            <p>You are responsible for ensuring that the content you create does not violate any laws or third-party rights.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground">6. Acceptable Use</h2>
            <p>You agree not to use the Service to:</p>
            <ul className="list-disc pl-6 space-y-1">
              <li>Violate any applicable laws or regulations</li>
              <li>Create resumes containing false, misleading, or fraudulent information</li>
              <li>Infringe upon the intellectual property rights of others</li>
              <li>Attempt to gain unauthorized access to our systems or other users' accounts</li>
              <li>Share your account credentials with others</li>
              <li>Reverse engineer, decompile, or modify the Service or its components</li>
              <li>Use automated tools to access the Service in a manner that overloads our infrastructure</li>
              <li>Transmit malware, viruses, or other harmful code</li>
            </ul>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground">7. Intellectual Property</h2>
            <p>The Resume Builder Pro platform, including its software, templates, designs, logos, and documentation, is the intellectual property of Resume Builder Pro and is protected by applicable intellectual property laws. You may not:</p>
            <ul className="list-disc pl-6 space-y-1">
              <li>Copy, modify, or distribute our templates or software</li>
              <li>Use our trademarks, logos, or branding without permission</li>
              <li>Remove or alter any proprietary notices on the Service</li>
              <li>Create derivative works based on our templates or platform</li>
            </ul>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground">8. Service Availability</h2>
            <p>We strive to provide continuous, uninterrupted access to the Service. However, we do not guarantee that the Service will be available at all times. We may experience hardware, software, or other problems, or need to perform maintenance, resulting in interruptions, delays, or errors. We reserve the right to change, revise, update, suspend, discontinue, or otherwise modify the Service at any time without notice.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground">9. Limitation of Liability</h2>
            <p>The Service is provided "as is" and "as available" without warranties of any kind, either express or implied, including but not limited to implied warranties of merchantability, fitness for a particular purpose, or non-infringement.</p>
            <p>In no event shall Resume Builder Pro, its directors, employees, or agents be liable for any indirect, incidental, special, consequential, or punitive damages, including but not limited to loss of data, business interruption, or loss of profits, arising from your use of or inability to use the Service.</p>
            <p>We are not responsible for the accuracy, completeness, or usefulness of any resume content created using our Service. Users are solely responsible for verifying the information in their resumes.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground">10. Indemnification</h2>
            <p>You agree to indemnify and hold harmless Resume Builder Pro, its directors, employees, and agents from any claims, damages, losses, liabilities, and expenses (including legal fees) arising from your use of the Service or your violation of these Terms.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground">11. Termination</h2>
            <p>We may suspend or terminate your account at our discretion if you violate these Terms. Upon termination, your right to use the Service will immediately cease. You may delete your account at any time by contacting us. Upon account deletion, your personal data and saved resumes will be removed from our systems.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground">12. Governing Law</h2>
            <p>These Terms shall be governed by and construed in accordance with applicable laws. Any disputes arising from these Terms or your use of the Service shall be resolved through appropriate legal channels.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground">13. Changes to Terms</h2>
            <p>We reserve the right to modify or replace these Terms at any time. If a revision is material, we will try to provide at least 30 days' notice prior to any new terms taking effect. What constitutes a material change will be determined at our sole discretion. Your continued use of the Service after any changes constitutes acceptance of the new Terms.</p>
          </section>

          <section>
            <h2 className="text-xl font-semibold text-foreground">14. Contact</h2>
            <p>If you have questions about these Terms & Conditions, please contact us:</p>
            <ul className="list-none space-y-1">
              <li>Email: <a href="mailto:alamyasin718@gmail.com" className="text-primary hover:underline">alamyasin718@gmail.com</a></li>
              <li>Contact Page: <Link to="/contact" className="text-primary hover:underline">Contact Us</Link></li>
            </ul>
          </section>
        </div>
      </div>
    </div>
  );
}
