import { useResume } from '@/contexts/ResumeContext';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Check } from 'lucide-react';
import type { TemplateId } from '@/types/resume';

interface TemplateInfo {
  id: TemplateId;
  name: string;
  description: string;
  preview: string;
}

const templates: TemplateInfo[] = [
  { id: 'classic', name: 'Classic', description: 'Traditional serif layout, clean and professional. Perfect for corporate roles.', preview: 'Aa' },
  { id: 'modern', name: 'Modern', description: 'Two-column design with timeline accents. Great for tech and creative fields.', preview: 'Aa' },
  { id: 'executive', name: 'Executive', description: 'Dark sidebar with accents. Ideal for senior leadership positions.', preview: 'Aa' },
];

export default function TemplatesPage() {
  const { selectedTemplate, setSelectedTemplate } = useResume();
  const navigate = useNavigate();

  const handleSelect = (template: TemplateInfo) => {
    setSelectedTemplate(template.id);
    navigate('/dashboard/create');
  };

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <div className="mb-8">
        <h2 className="text-2xl font-bold">Resume Templates</h2>
        <p className="text-muted-foreground mt-1">Choose a template that matches your style</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {templates.map((template) => {
          const isSelected = selectedTemplate === template.id;

          return (
            <Card
              key={template.id}
              className={`relative cursor-pointer transition-all hover:shadow-md ${
                isSelected ? 'ring-2 ring-primary' : ''
              }`}
              onClick={() => handleSelect(template)}
            >
              {/* Template Preview */}
              <div className="aspect-[3/4] bg-muted/50 border-b flex items-center justify-center overflow-hidden">
                {template.id === 'classic' && (
                  <div className="w-[80%] h-[85%] bg-white shadow-sm p-3" style={{ fontSize: '4px' }}>
                    <div className="text-center border-b border-gray-300 pb-1 mb-1">
                      <div className="font-bold" style={{ fontSize: '7px' }}>John Doe</div>
                      <div className="text-gray-500" style={{ fontSize: '3px' }}>john@email.com | +1 555-0000</div>
                    </div>
                    <div className="border-b border-gray-200 pb-0.5 mb-1">
                      <div className="font-bold uppercase" style={{ fontSize: '4px' }}>Summary</div>
                      <div className="text-gray-400" style={{ fontSize: '3px' }}>Professional summary...</div>
                    </div>
                    <div className="border-b border-gray-200 pb-0.5 mb-1">
                      <div className="font-bold uppercase" style={{ fontSize: '4px' }}>Experience</div>
                      <div className="font-semibold" style={{ fontSize: '3.5px' }}>Software Engineer</div>
                      <div className="text-gray-400" style={{ fontSize: '3px' }}>Company Name</div>
                    </div>
                    <div>
                      <div className="font-bold uppercase" style={{ fontSize: '4px' }}>Education</div>
                      <div className="font-semibold" style={{ fontSize: '3.5px' }}>B.S. Computer Science</div>
                    </div>
                  </div>
                )}
                {template.id === 'modern' && (
                  <div className="w-[80%] h-[85%] bg-white shadow-sm overflow-hidden" style={{ fontSize: '4px' }}>
                    <div className="bg-slate-800 text-white p-3">
                      <div className="font-light" style={{ fontSize: '7px' }}>John Doe</div>
                      <div className="text-slate-300" style={{ fontSize: '3px' }}>john@email.com</div>
                    </div>
                    <div className="p-3 grid grid-cols-3 gap-2">
                      <div className="col-span-2">
                        <div className="font-bold uppercase" style={{ fontSize: '4px' }}>Experience</div>
                        <div className="pl-2 border-l border-slate-200 mt-1">
                          <div className="font-semibold" style={{ fontSize: '3.5px' }}>Software Engineer</div>
                        </div>
                      </div>
                      <div className="col-span-1">
                        <div className="font-bold uppercase" style={{ fontSize: '4px' }}>Skills</div>
                        <div className="flex flex-wrap gap-0.5 mt-1">
                          <span className="bg-slate-100 px-1 rounded" style={{ fontSize: '3px' }}>React</span>
                          <span className="bg-slate-100 px-1 rounded" style={{ fontSize: '3px' }}>TS</span>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
                {template.id === 'executive' && (
                  <div className="w-[80%] h-[85%] bg-white shadow-sm overflow-hidden grid grid-cols-3" style={{ fontSize: '4px' }}>
                    <div className="col-span-1 bg-gray-900 text-white p-2">
                      <div className="font-bold" style={{ fontSize: '6px' }}>John Doe</div>
                      <div className="text-gray-400 mt-2" style={{ fontSize: '3px' }}>Contact</div>
                      <div className="text-gray-300" style={{ fontSize: '3px' }}>john@email.com</div>
                      <div className="text-gray-400 mt-2" style={{ fontSize: '3px' }}>Skills</div>
                      <div className="flex items-center gap-0.5">
                        <div className="w-0.5 h-0.5 rounded-full bg-amber-400" />
                        <span className="text-gray-300" style={{ fontSize: '3px' }}>React</span>
                      </div>
                    </div>
                    <div className="col-span-2 p-2">
                      <div className="font-bold uppercase border-b-2 border-amber-500 pb-0.5 inline-block" style={{ fontSize: '4px' }}>Summary</div>
                      <div className="text-gray-400 mt-1" style={{ fontSize: '3px' }}>Professional summary...</div>
                      <div className="font-bold uppercase border-b-2 border-amber-500 pb-0.5 inline-block mt-2" style={{ fontSize: '4px' }}>Experience</div>
                    </div>
                  </div>
                )}
              </div>

              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2">
                  {template.name}
                  {isSelected && <Check className="h-4 w-4 text-primary" />}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">{template.description}</p>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
