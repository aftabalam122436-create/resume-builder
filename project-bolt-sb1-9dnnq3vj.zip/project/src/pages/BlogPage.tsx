import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ArrowRight, Clock, User } from 'lucide-react';
import { blogPosts } from '@/data/blogPosts';
import SEO from '@/components/SEO';

export default function BlogPage() {
  return (
    <div className="min-h-screen bg-background">
      <SEO
        title="Resume & Career Blog - Resume Builder Pro"
        description="Expert tips, guides, and advice on resume writing, interview preparation, and career development. Learn how to create the perfect resume."
        keywords="resume tips, career advice, resume writing guide, interview tips, job search"
      />
      {/* Header */}
      <nav className="sticky top-0 z-40 border-b bg-card/80 backdrop-blur-sm">
        <div className="max-w-6xl mx-auto px-4 h-14 flex items-center justify-between">
          <Link to="/" className="font-bold text-lg">Resume Builder Pro</Link>
          <Link to="/"><Button variant="ghost" size="sm">Home</Button></Link>
        </div>
      </nav>

      {/* Hero */}
      <section className="bg-gradient-to-br from-primary/10 via-transparent to-primary/5 py-16 border-b">
        <div className="max-w-6xl mx-auto px-4">
          <div className="text-center mb-4">
            <h1 className="text-4xl sm:text-5xl font-bold mb-4">Resume & Career Blog</h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Expert tips, guides, and advice to help you create the perfect resume and advance your career.
            </p>
          </div>
        </div>
      </section>

      {/* Blog Posts */}
      <section className="py-16">
        <div className="max-w-6xl mx-auto px-4">
          {/* Featured Post */}
          {blogPosts.length > 0 && (
            <div className="mb-16">
              <Link to={`/blog/${blogPosts[0].slug}`}>
                <Card className="hover:shadow-lg transition-shadow cursor-pointer border-primary/50 bg-gradient-to-br from-primary/5 to-transparent">
                  <CardHeader className="pb-2">
                    <div className="flex items-center gap-3 mb-3">
                      <Badge className="bg-primary">{blogPosts[0].category}</Badge>
                      <Badge variant="outline">{blogPosts[0].readTime} min read</Badge>
                    </div>
                    <CardTitle className="text-2xl">{blogPosts[0].title}</CardTitle>
                    <CardDescription className="text-base mt-2">{blogPosts[0].excerpt}</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex items-center gap-6 text-sm text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <User className="h-4 w-4" />
                        {blogPosts[0].author}
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="h-4 w-4" />
                        {new Date(blogPosts[0].date).toLocaleDateString()}
                      </div>
                    </div>
                    <Button className="gap-2">
                      Read Featured Article
                      <ArrowRight className="h-4 w-4" />
                    </Button>
                  </CardContent>
                </Card>
              </Link>
            </div>
          )}

          {/* All Posts Grid */}
          <div>
            <h2 className="text-2xl font-bold mb-8">Latest Articles</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {blogPosts.slice(1).map((post) => (
                <Link key={post.id} to={`/blog/${post.slug}`}>
                  <Card className="h-full hover:shadow-lg transition-shadow cursor-pointer">
                    <CardHeader>
                      <div className="flex items-center justify-between gap-2 mb-2">
                        <Badge variant="secondary" className="text-xs">{post.category}</Badge>
                        <span className="text-xs text-muted-foreground whitespace-nowrap">{post.readTime} min</span>
                      </div>
                      <CardTitle className="line-clamp-2 text-lg">{post.title}</CardTitle>
                      <CardDescription className="line-clamp-2 mt-2">{post.excerpt}</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-3 pt-0">
                      <div className="flex items-center gap-4 text-xs text-muted-foreground">
                        <div className="flex items-center gap-1">
                          <User className="h-3 w-3" />
                          {post.author}
                        </div>
                        <div className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {new Date(post.date).toLocaleDateString()}
                        </div>
                      </div>
                      <Button variant="ghost" className="w-full justify-between group">
                        Read More
                        <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
                      </Button>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-muted/50 border-t border-b py-12">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-2xl font-bold mb-3">Ready to Build Your Resume?</h2>
          <p className="text-muted-foreground mb-6 max-w-xl mx-auto">
            Use our free resume builder to create a professional, ATS-optimized resume in minutes.
          </p>
          <Link to="/signup"><Button size="lg">Get Started Free</Button></Link>
        </div>
      </section>
    </div>
  );
}
