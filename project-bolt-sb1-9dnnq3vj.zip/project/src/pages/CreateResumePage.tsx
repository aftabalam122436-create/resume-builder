import { useState, useEffect, useCallback } from 'react';
import { useResume } from '@/contexts/ResumeContext';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import PersonalInfoForm from '@/components/resume/PersonalInfoForm';
import EducationForm from '@/components/resume/EducationForm';
import ExperienceForm from '@/components/resume/ExperienceForm';
import SkillsForm from '@/components/resume/SkillsForm';
import ProjectsForm from '@/components/resume/ProjectsForm';
import CertificationsForm from '@/components/resume/CertificationsForm';
import ResumePreview from '@/components/resume/ResumePreview';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from '@/hooks/use-toast';
import { Save, Download, RotateCcw, Loader as Loader2 } from 'lucide-react';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';

export default function CreateResumePage() {
  const { resumeData, selectedTemplate, resumeTitle, setResumeTitle, resetResume, loadResume } = useResume();
  const { user } = useAuth();
  const [saving, setSaving] = useState(false);
  const [downloading, setDownloading] = useState(false);
  const [activeTab, setActiveTab] = useState('personal');

  // Auto-save draft to localStorage
  useEffect(() => {
    const timer = setTimeout(() => {
      localStorage.setItem('resume-draft', JSON.stringify({ data: resumeData, template: selectedTemplate, title: resumeTitle }));
    }, 1000);
    return () => clearTimeout(timer);
  }, [resumeData, selectedTemplate, resumeTitle]);

  // Load draft from localStorage on mount
  useEffect(() => {
    const draft = localStorage.getItem('resume-draft');
    if (draft) {
      try {
        const parsed = JSON.parse(draft);
        if (parsed.data?.personalInfo?.fullName) {
          loadResume(parsed.data, parsed.template, parsed.title);
        }
      } catch {
        // ignore
      }
    }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const handleSave = useCallback(async () => {
    if (!user) return;
    setSaving(true);
    try {
      const { error } = await supabase.from('resumes').insert({
        user_id: user.id,
        title: resumeTitle,
        data: resumeData,
        template: selectedTemplate,
        is_premium: false,
      });
      if (error) throw error;
      toast({ title: 'Resume saved successfully' });
    } catch {
      // Fallback to localStorage
      const existing = JSON.parse(localStorage.getItem('saved-resumes') || '[]');
      localStorage.setItem('saved-resumes', JSON.stringify([
        ...existing,
        { id: crypto.randomUUID(), title: resumeTitle, data: resumeData, template: selectedTemplate, created_at: new Date().toISOString(), updated_at: new Date().toISOString() }
      ]));
      toast({ title: 'Resume saved locally' });
    }
    setSaving(false);
  }, [user, resumeTitle, resumeData, selectedTemplate]);

  const handleDownload = useCallback(async () => {
    setDownloading(true);
    try {
      const element = document.getElementById('resume-preview');
      if (!element) return;

      const canvas = await html2canvas(element, {
        scale: 2,
        useCORS: true,
        logging: false,
        backgroundColor: '#ffffff',
      });

      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('p', 'mm', 'a4');
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = pdf.internal.pageSize.getHeight();
      const imgWidth = canvas.width;
      const imgHeight = canvas.height;
      const ratio = Math.min(pdfWidth / imgWidth, pdfHeight / imgHeight);
      const imgX = (pdfWidth - imgWidth * ratio) / 2;

      pdf.addImage(imgData, 'PNG', imgX, 0, imgWidth * ratio, imgHeight * ratio);
      pdf.save(`${resumeTitle.replace(/\s+/g, '_')}.pdf`);
      toast({ title: 'PDF downloaded successfully' });
    } catch {
      toast({ title: 'Failed to generate PDF', variant: 'destructive' });
    }
    setDownloading(false);
  }, [resumeTitle]);

  return (
    <div className="h-full flex flex-col">
      {/* Toolbar */}
      <div className="border-b bg-card px-4 py-3 flex items-center gap-3 flex-wrap">
        <Input
          value={resumeTitle}
          onChange={e => setResumeTitle(e.target.value)}
          className="max-w-xs font-medium"
          placeholder="Resume title..."
        />
        <div className="flex-1" />
        <Button variant="outline" size="sm" onClick={resetResume} className="gap-1.5">
          <RotateCcw className="h-3.5 w-3.5" /> Reset
        </Button>
        <Button variant="outline" size="sm" onClick={handleSave} disabled={saving} className="gap-1.5">
          {saving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />}
          Save
        </Button>
        <Button size="sm" onClick={handleDownload} disabled={downloading} className="gap-1.5">
          {downloading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Download className="h-3.5 w-3.5" />}
          Download PDF
        </Button>
      </div>

      {/* Content */}
      <div className="flex-1 flex flex-col lg:flex-row overflow-hidden">
        {/* Form Panel */}
        <div className="lg:w-1/2 w-full lg:border-r overflow-auto p-4">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="w-full grid grid-cols-3 mb-4">
              <TabsTrigger value="personal">Personal</TabsTrigger>
              <TabsTrigger value="experience">Experience</TabsTrigger>
              <TabsTrigger value="education">Education</TabsTrigger>
            </TabsList>
            <TabsList className="w-full grid grid-cols-3 mb-4">
              <TabsTrigger value="skills">Skills</TabsTrigger>
              <TabsTrigger value="projects">Projects</TabsTrigger>
              <TabsTrigger value="certifications">Certs</TabsTrigger>
            </TabsList>

            <TabsContent value="personal"><PersonalInfoForm /></TabsContent>
            <TabsContent value="experience"><ExperienceForm /></TabsContent>
            <TabsContent value="education"><EducationForm /></TabsContent>
            <TabsContent value="skills"><SkillsForm /></TabsContent>
            <TabsContent value="projects"><ProjectsForm /></TabsContent>
            <TabsContent value="certifications"><CertificationsForm /></TabsContent>
          </Tabs>
        </div>

        {/* Preview Panel */}
        <div className="lg:w-1/2 w-full overflow-hidden">
          <ResumePreview />
        </div>
      </div>
    </div>
  );
}
