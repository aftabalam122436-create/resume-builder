import { Link, useParams, Navigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { ArrowLeft, Clock, User, ArrowRight } from 'lucide-react';
import { blogPosts } from '@/data/blogPosts';
import SEO from '@/components/SEO';

function renderMarkdown(text: string) {
  const lines = text.split('\n');
  const elements: React.ReactNode[] = [];
  let key = 0;
  let listItems: React.ReactNode[] = [];

  const flushList = () => {
    if (listItems.length > 0) {
      elements.push(<ul key={`ul-${key++}`} className="list-disc pl-6 space-y-1 mb-4">{listItems}</ul>);
      listItems = [];
    }
  };

  for (const line of lines) {
    const trimmed = line.trim();
    if (trimmed === '') { flushList(); continue; }
    if (trimmed.startsWith('### ')) {
      flushList();
      elements.push(<h3 key={key++} className="text-xl font-semibold text-foreground mt-6 mb-2">{trimmed.slice(4)}</h3>);
    } else if (trimmed.startsWith('## ')) {
      flushList();
      elements.push(<h2 key={key++} className="text-2xl font-semibold text-foreground mt-8 mb-3">{trimmed.slice(3)}</h2>);
    } else if (trimmed.startsWith('- ') || trimmed.startsWith('• ')) {
      listItems.push(<li key={`li-${key++}`} className="text-muted-foreground">{parseInline(trimmed.slice(2))}</li>);
    } else if (trimmed.startsWith('~~~') && trimmed.endsWith('~~~')) {
      flushList();
      elements.push(<pre key={key++} className="bg-muted p-4 rounded-lg overflow-x-auto text-sm mb-4"><code>{trimmed.slice(3, -3)}</code></pre>);
    } else if (trimmed.startsWith('|') && trimmed.endsWith('|')) {
      flushList();
      elements.push(<p key={key++} className="text-muted-foreground mb-4 font-mono text-xs whitespace-pre overflow-x-auto">{trimmed}</p>);
    } else {
      flushList();
      elements.push(<p key={key++} className="text-muted-foreground mb-4">{parseInline(trimmed)}</p>);
    }
  }
  flushList();
  return elements;
}

function parseInline(text: string): React.ReactNode {
  const parts: React.ReactNode[] = [];
  let remaining = text;
  let pk = 0;
  while (remaining.length > 0) {
    const bold = remaining.match(/\*\*(.+?)\*\*/);
    if (bold && bold.index !== undefined) {
      if (bold.index > 0) parts.push(remaining.slice(0, bold.index));
      parts.push(<strong key={pk++} className="text-foreground font-semibold">{bold[1]}</strong>);
      remaining = remaining.slice(bold.index + bold[0].length);
    } else {
      parts.push(remaining);
      break;
    }
  }
  return <>{parts}</>;
}

export default function BlogPostPage() {
  const { slug } = useParams<{ slug: string }>();
  const post = blogPosts.find(p => p.slug === slug);

  if (!post) return <Navigate to="/blog" replace />;

  const related = blogPosts.filter(p => p.id !== post.id).slice(0, 3);

  return (
    <>
      <SEO
        title={`${post.title} - Resume Builder Pro`}
        description={post.description}
        keywords={post.keywords.join(', ')}
      />
      <div className="min-h-screen bg-background">
        <nav className="sticky top-0 z-40 border-b bg-card/80 backdrop-blur-sm">
          <div className="max-w-4xl mx-auto px-4 h-14 flex items-center">
            <Link to="/blog"><Button variant="ghost" size="sm" className="gap-1.5"><ArrowLeft className="h-4 w-4" /> All Articles</Button></Link>
          </div>
        </nav>

        <article className="max-w-4xl mx-auto px-4 py-12">
          <header className="mb-8">
            <Badge className="mb-4">{post.category}</Badge>
            <h1 className="text-3xl sm:text-4xl font-bold mb-4 leading-tight">{post.title}</h1>
            <p className="text-lg text-muted-foreground mb-4">{post.description}</p>
            <div className="flex items-center gap-6 text-sm text-muted-foreground flex-wrap">
              <div className="flex items-center gap-1.5"><User className="h-4 w-4" /> {post.author}</div>
              <div className="flex items-center gap-1.5"><Clock className="h-4 w-4" /> {post.readTime} min read</div>
              <div>{new Date(post.date).toLocaleDateString()}</div>
            </div>
          </header>

          <div className="prose prose-sm dark:prose-invert max-w-none">
            {renderMarkdown(post.content)}
          </div>

          <Card className="mt-12 bg-primary/5 border-primary/20">
            <CardContent className="py-8 text-center">
              <h3 className="text-xl font-bold mb-2">Ready to Build Your Resume?</h3>
              <p className="text-muted-foreground mb-4">Create a professional, ATS-optimized resume for free.</p>
              <Link to="/signup"><Button size="lg" className="gap-2">Get Started Free <ArrowRight className="h-4 w-4" /></Button></Link>
            </CardContent>
          </Card>

          {related.length > 0 && (
            <div className="mt-12">
              <h3 className="text-xl font-bold mb-6">Related Articles</h3>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {related.map(rp => (
                  <Link key={rp.id} to={`/blog/${rp.slug}`}>
                    <Card className="hover:shadow-md transition-shadow h-full">
                      <CardContent className="pt-4">
                        <Badge variant="secondary" className="text-xs mb-2">{rp.category}</Badge>
                        <h4 className="font-semibold text-sm leading-snug">{rp.title}</h4>
                        <p className="text-xs text-muted-foreground mt-1">{rp.readTime} min read</p>
                      </CardContent>
                    </Card>
                  </Link>
                ))}
              </div>
            </div>
          )}
        </article>
      </div>
    </>
  );
}
