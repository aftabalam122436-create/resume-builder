import { useResume } from '@/contexts/ResumeContext';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { GraduationCap, Plus, Trash2 } from 'lucide-react';

export default function EducationForm() {
  const { resumeData, addEducation, updateEducation, removeEducation } = useResume();
  const { education } = resumeData;

  return (
    <Card>
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-base">
            <GraduationCap className="h-4 w-4" /> Education
          </CardTitle>
          <Button variant="outline" size="sm" onClick={addEducation} className="gap-1">
            <Plus className="h-3 w-3" /> Add
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {education.map((edu, index) => (
          <div key={edu.id} className="relative space-y-4 pb-6 border-b last:border-0 last:pb-0">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-muted-foreground">Education #{index + 1}</span>
              {education.length > 1 && (
                <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" onClick={() => removeEducation(edu.id)}>
                  <Trash2 className="h-3.5 w-3.5" />
                </Button>
              )}
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Institution</Label>
                <Input placeholder="University Name" value={edu.institution} onChange={e => updateEducation(edu.id, 'institution', e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Degree</Label>
                <Input placeholder="Bachelor of Science" value={edu.degree} onChange={e => updateEducation(edu.id, 'degree', e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Field of Study</Label>
                <Input placeholder="Computer Science" value={edu.field} onChange={e => updateEducation(edu.id, 'field', e.target.value)} />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div className="space-y-2">
                  <Label>Start Date</Label>
                  <Input placeholder="2018" value={edu.startDate} onChange={e => updateEducation(edu.id, 'startDate', e.target.value)} />
                </div>
                <div className="space-y-2">
                  <Label>End Date</Label>
                  <Input placeholder="2022" value={edu.endDate} onChange={e => updateEducation(edu.id, 'endDate', e.target.value)} />
                </div>
              </div>
            </div>
            <div className="space-y-2">
              <Label>Description</Label>
              <Textarea placeholder="Relevant coursework, honors, activities..." value={edu.description} onChange={e => updateEducation(edu.id, 'description', e.target.value)} rows={2} />
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}
