import { useResume } from '@/contexts/ResumeContext';
import ClassicTemplate from '@/components/templates/ClassicTemplate';
import ModernTemplate from '@/components/templates/ModernTemplate';
import ExecutiveTemplate from '@/components/templates/ExecutiveTemplate';
import type { TemplateId } from '@/types/resume';

const templateMap: Record<TemplateId, React.ComponentType<{ data: import('@/types/resume').ResumeData }>> = {
  classic: ClassicTemplate,
  modern: ModernTemplate,
  executive: ExecutiveTemplate,
};

export default function ResumePreview() {
  const { resumeData, selectedTemplate } = useResume();
  const TemplateComponent = templateMap[selectedTemplate];

  return (
    <div className="flex flex-col h-full">
      <div className="text-center py-2 text-xs text-muted-foreground font-medium uppercase tracking-wider">
        Live Preview
      </div>
      <div className="flex-1 overflow-auto bg-muted/30 p-4 flex justify-center">
        <div
          className="bg-white shadow-lg w-full max-w-[595px]"
          style={{
            aspectRatio: '210 / 297',
            minHeight: '297mm',
          }}
          id="resume-preview"
        >
          <TemplateComponent data={resumeData} />
        </div>
      </div>
    </div>
  );
}
