import { useResume } from '@/contexts/ResumeContext';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { FolderGit2, Plus, Trash2 } from 'lucide-react';

export default function ProjectsForm() {
  const { resumeData, addProject, updateProject, removeProject } = useResume();
  const { projects } = resumeData;

  return (
    <Card>
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-base">
            <FolderGit2 className="h-4 w-4" /> Projects
          </CardTitle>
          <Button variant="outline" size="sm" onClick={addProject} className="gap-1">
            <Plus className="h-3 w-3" /> Add
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {projects.length === 0 && (
          <p className="text-sm text-muted-foreground text-center py-4">No projects added yet. Click "Add" to get started.</p>
        )}
        {projects.map((proj, index) => (
          <div key={proj.id} className="relative space-y-4 pb-6 border-b last:border-0 last:pb-0">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-muted-foreground">Project #{index + 1}</span>
              <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" onClick={() => removeProject(proj.id)}>
                <Trash2 className="h-3.5 w-3.5" />
              </Button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Project Name</Label>
                <Input placeholder="My Project" value={proj.name} onChange={e => updateProject(proj.id, 'name', e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>URL</Label>
                <Input placeholder="https://..." value={proj.url} onChange={e => updateProject(proj.id, 'url', e.target.value)} />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Description</Label>
              <Textarea placeholder="Brief description of the project..." value={proj.description} onChange={e => updateProject(proj.id, 'description', e.target.value)} rows={2} />
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}
