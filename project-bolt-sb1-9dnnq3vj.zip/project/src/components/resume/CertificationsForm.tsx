import { useResume } from '@/contexts/ResumeContext';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Award, Plus, Trash2 } from 'lucide-react';

export default function CertificationsForm() {
  const { resumeData, addCertification, updateCertification, removeCertification } = useResume();
  const { certifications } = resumeData;

  return (
    <Card>
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-base">
            <Award className="h-4 w-4" /> Certifications
          </CardTitle>
          <Button variant="outline" size="sm" onClick={addCertification} className="gap-1">
            <Plus className="h-3 w-3" /> Add
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {certifications.length === 0 && (
          <p className="text-sm text-muted-foreground text-center py-4">No certifications added yet. Click "Add" to get started.</p>
        )}
        {certifications.map((cert, index) => (
          <div key={cert.id} className="relative space-y-4 pb-6 border-b last:border-0 last:pb-0">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-muted-foreground">Certification #{index + 1}</span>
              <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" onClick={() => removeCertification(cert.id)}>
                <Trash2 className="h-3.5 w-3.5" />
              </Button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label>Name</Label>
                <Input placeholder="AWS Certified" value={cert.name} onChange={e => updateCertification(cert.id, 'name', e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Issuer</Label>
                <Input placeholder="Amazon" value={cert.issuer} onChange={e => updateCertification(cert.id, 'issuer', e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Date</Label>
                <Input placeholder="2023" value={cert.date} onChange={e => updateCertification(cert.id, 'date', e.target.value)} />
              </div>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}
