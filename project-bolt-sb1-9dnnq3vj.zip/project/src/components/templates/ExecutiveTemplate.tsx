import type { ResumeData } from '@/types/resume';

interface TemplateProps {
  data: ResumeData;
}

export default function ExecutiveTemplate({ data }: TemplateProps) {
  const { personalInfo, education, experience, skills, projects, certifications } = data;

  return (
    <div className="bg-white text-gray-900 font-sans" style={{ fontSize: '10px', lineHeight: '1.4' }}>
      {/* Sidebar + Main layout */}
      <div className="grid grid-cols-3 min-h-full">
        {/* Sidebar */}
        <div className="col-span-1 bg-gray-900 text-white px-6 py-8">
          {/* Name */}
          <div className="mb-6">
            <h1 className="text-xl font-bold leading-tight" style={{ fontSize: '20px' }}>
              {personalInfo.fullName || 'Your Name'}
            </h1>
          </div>

          {/* Contact */}
          <div className="mb-6">
            <h2 className="text-xs font-bold uppercase tracking-widest text-gray-400 mb-3">Contact</h2>
            <div className="space-y-1.5" style={{ fontSize: '9px' }}>
              {personalInfo.email && <p className="break-all">{personalInfo.email}</p>}
              {personalInfo.phone && <p>{personalInfo.phone}</p>}
              {personalInfo.address && <p>{personalInfo.address}</p>}
              {personalInfo.website && <p className="break-all">{personalInfo.website}</p>}
              {personalInfo.linkedin && <p className="break-all">{personalInfo.linkedin}</p>}
            </div>
          </div>

          {/* Skills */}
          {skills.length > 0 && (
            <div className="mb-6">
              <h2 className="text-xs font-bold uppercase tracking-widest text-gray-400 mb-3">Skills</h2>
              <div className="space-y-1.5">
                {skills.map(skill => (
                  <div key={skill} className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full bg-amber-400 shrink-0" />
                    <span style={{ fontSize: '9px' }}>{skill}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Education */}
          {education.some(e => e.institution || e.degree) && (
            <div className="mb-6">
              <h2 className="text-xs font-bold uppercase tracking-widest text-gray-400 mb-3">Education</h2>
              {education.map(edu => (
                <div key={edu.id} className="mb-3">
                  <p className="font-semibold" style={{ fontSize: '9px' }}>{edu.degree}{edu.field ? ` in ${edu.field}` : ''}</p>
                  <p className="text-gray-400" style={{ fontSize: '9px' }}>{edu.institution}</p>
                  <p className="text-gray-500" style={{ fontSize: '8px' }}>{edu.startDate}{edu.endDate ? ` - ${edu.endDate}` : ''}</p>
                </div>
              ))}
            </div>
          )}

          {/* Certifications */}
          {certifications.some(c => c.name) && (
            <div className="mb-6">
              <h2 className="text-xs font-bold uppercase tracking-widest text-gray-400 mb-3">Certifications</h2>
              {certifications.map(cert => (
                <div key={cert.id} className="mb-2">
                  <p className="font-semibold" style={{ fontSize: '9px' }}>{cert.name}</p>
                  {cert.issuer && <p className="text-gray-400" style={{ fontSize: '9px' }}>{cert.issuer}</p>}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Main Content */}
        <div className="col-span-2 px-8 py-8">
          {/* Summary */}
          {personalInfo.summary && (
            <div className="mb-6">
              <h2 className="text-xs font-bold uppercase tracking-widest text-gray-900 mb-2 border-b-2 border-amber-500 pb-1 inline-block">Professional Summary</h2>
              <p className="text-gray-600 mt-3 leading-relaxed">{personalInfo.summary}</p>
            </div>
          )}

          {/* Experience */}
          {experience.some(e => e.company || e.position) && (
            <div className="mb-6">
              <h2 className="text-xs font-bold uppercase tracking-widest text-gray-900 mb-3 border-b-2 border-amber-500 pb-1 inline-block">Professional Experience</h2>
              {experience.map(exp => (
                <div key={exp.id} className="mb-4 mt-3">
                  <div className="flex justify-between items-baseline">
                    <h3 className="font-bold text-gray-900">{exp.position}</h3>
                    <span className="text-gray-400" style={{ fontSize: '9px' }}>{exp.startDate}{exp.endDate ? ` - ${exp.endDate}` : ''}</span>
                  </div>
                  <p className="text-amber-700 font-medium">{exp.company}</p>
                  {exp.description && <p className="mt-1 text-gray-600 whitespace-pre-line">{exp.description}</p>}
                </div>
              ))}
            </div>
          )}

          {/* Projects */}
          {projects.some(p => p.name) && (
            <div className="mb-6">
              <h2 className="text-xs font-bold uppercase tracking-widest text-gray-900 mb-3 border-b-2 border-amber-500 pb-1 inline-block">Key Projects</h2>
              {projects.map(proj => (
                <div key={proj.id} className="mb-3 mt-3">
                  <h3 className="font-bold text-gray-900">{proj.name}</h3>
                  {proj.url && <p className="text-blue-600" style={{ fontSize: '9px' }}>{proj.url}</p>}
                  {proj.description && <p className="text-gray-600 mt-1">{proj.description}</p>}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
