import type { ResumeData } from '@/types/resume';

interface TemplateProps {
  data: ResumeData;
}

export default function ModernTemplate({ data }: TemplateProps) {
  const { personalInfo, education, experience, skills, projects, certifications } = data;

  return (
    <div className="bg-white text-gray-900 font-sans" style={{ fontSize: '10px', lineHeight: '1.4' }}>
      {/* Header with accent bar */}
      <div className="bg-slate-800 text-white px-8 py-6">
        <h1 className="text-2xl font-light tracking-wide" style={{ fontSize: '24px' }}>
          {personalInfo.fullName || 'Your Name'}
        </h1>
        <div className="flex flex-wrap gap-x-4 gap-y-1 mt-2 text-slate-300" style={{ fontSize: '9px' }}>
          {personalInfo.email && <span>{personalInfo.email}</span>}
          {personalInfo.phone && <span>{personalInfo.phone}</span>}
          {personalInfo.address && <span>{personalInfo.address}</span>}
          {personalInfo.website && <span>{personalInfo.website}</span>}
          {personalInfo.linkedin && <span>{personalInfo.linkedin}</span>}
        </div>
      </div>

      <div className="px-8 py-6">
        {/* Summary */}
        {personalInfo.summary && (
          <div className="mb-5">
            <h2 className="text-xs font-bold uppercase tracking-widest text-slate-800 mb-2">Profile</h2>
            <p className="text-gray-600 leading-relaxed">{personalInfo.summary}</p>
          </div>
        )}

        <div className="grid grid-cols-3 gap-6">
          {/* Left column - 2/3 */}
          <div className="col-span-2">
            {/* Experience */}
            {experience.some(e => e.company || e.position) && (
              <div className="mb-5">
                <h2 className="text-xs font-bold uppercase tracking-widest text-slate-800 mb-3">Experience</h2>
                {experience.map(exp => (
                  <div key={exp.id} className="mb-4 relative pl-4 border-l-2 border-slate-200">
                    <div className="absolute -left-1.5 top-0.5 w-2 h-2 rounded-full bg-slate-800" />
                    <div className="flex justify-between items-baseline">
                      <h3 className="font-semibold text-gray-900">{exp.position}</h3>
                      <span className="text-gray-400" style={{ fontSize: '9px' }}>{exp.startDate}{exp.endDate ? ` - ${exp.endDate}` : ''}</span>
                    </div>
                    <p className="text-slate-600 font-medium">{exp.company}</p>
                    {exp.description && <p className="mt-1 text-gray-600 whitespace-pre-line">{exp.description}</p>}
                  </div>
                ))}
              </div>
            )}

            {/* Projects */}
            {projects.some(p => p.name) && (
              <div className="mb-5">
                <h2 className="text-xs font-bold uppercase tracking-widest text-slate-800 mb-3">Projects</h2>
                {projects.map(proj => (
                  <div key={proj.id} className="mb-3">
                    <h3 className="font-semibold">{proj.name}</h3>
                    {proj.url && <p className="text-blue-600" style={{ fontSize: '9px' }}>{proj.url}</p>}
                    {proj.description && <p className="text-gray-600 mt-1">{proj.description}</p>}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Right column - 1/3 */}
          <div className="col-span-1">
            {/* Skills */}
            {skills.length > 0 && (
              <div className="mb-5">
                <h2 className="text-xs font-bold uppercase tracking-widest text-slate-800 mb-3">Skills</h2>
                <div className="flex flex-wrap gap-1.5">
                  {skills.map(skill => (
                    <span key={skill} className="bg-slate-100 text-slate-700 px-2 py-0.5 rounded" style={{ fontSize: '9px' }}>{skill}</span>
                  ))}
                </div>
              </div>
            )}

            {/* Education */}
            {education.some(e => e.institution || e.degree) && (
              <div className="mb-5">
                <h2 className="text-xs font-bold uppercase tracking-widest text-slate-800 mb-3">Education</h2>
                {education.map(edu => (
                  <div key={edu.id} className="mb-3">
                    <h3 className="font-semibold">{edu.degree}{edu.field ? ` in ${edu.field}` : ''}</h3>
                    <p className="text-gray-600">{edu.institution}</p>
                    <p className="text-gray-400" style={{ fontSize: '9px' }}>{edu.startDate}{edu.endDate ? ` - ${edu.endDate}` : ''}</p>
                  </div>
                ))}
              </div>
            )}

            {/* Certifications */}
            {certifications.some(c => c.name) && (
              <div className="mb-5">
                <h2 className="text-xs font-bold uppercase tracking-widest text-slate-800 mb-3">Certifications</h2>
                {certifications.map(cert => (
                  <div key={cert.id} className="mb-2">
                    <p className="font-semibold">{cert.name}</p>
                    {cert.issuer && <p className="text-gray-600">{cert.issuer}</p>}
                    {cert.date && <p className="text-gray-400" style={{ fontSize: '9px' }}>{cert.date}</p>}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
