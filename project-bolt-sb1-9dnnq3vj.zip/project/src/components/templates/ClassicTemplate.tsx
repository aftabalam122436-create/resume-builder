import type { ResumeData } from '@/types/resume';

interface TemplateProps {
  data: ResumeData;
}

export default function ClassicTemplate({ data }: TemplateProps) {
  const { personalInfo, education, experience, skills, projects, certifications } = data;

  return (
    <div className="bg-white text-gray-900 p-8 font-serif" style={{ fontSize: '10px', lineHeight: '1.4' }}>
      {/* Header */}
      <div className="text-center border-b-2 border-gray-800 pb-3 mb-4">
        <h1 className="text-2xl font-bold tracking-wide uppercase" style={{ fontSize: '22px' }}>
          {personalInfo.fullName || 'Your Name'}
        </h1>
        <div className="flex flex-wrap justify-center gap-x-3 gap-y-1 mt-2 text-gray-600" style={{ fontSize: '9px' }}>
          {personalInfo.email && <span>{personalInfo.email}</span>}
          {personalInfo.phone && <span>{personalInfo.phone}</span>}
          {personalInfo.address && <span>{personalInfo.address}</span>}
          {personalInfo.website && <span>{personalInfo.website}</span>}
          {personalInfo.linkedin && <span>{personalInfo.linkedin}</span>}
        </div>
      </div>

      {/* Summary */}
      {personalInfo.summary && (
        <div className="mb-4">
          <h2 className="text-xs font-bold uppercase tracking-wider border-b border-gray-300 pb-1 mb-2">Professional Summary</h2>
          <p className="text-gray-700">{personalInfo.summary}</p>
        </div>
      )}

      {/* Experience */}
      {experience.some(e => e.company || e.position) && (
        <div className="mb-4">
          <h2 className="text-xs font-bold uppercase tracking-wider border-b border-gray-300 pb-1 mb-2">Experience</h2>
          {experience.map(exp => (
            <div key={exp.id} className="mb-3">
              <div className="flex justify-between items-baseline">
                <h3 className="font-bold">{exp.position}</h3>
                <span className="text-gray-500" style={{ fontSize: '9px' }}>{exp.startDate}{exp.endDate ? ` - ${exp.endDate}` : ''}</span>
              </div>
              <p className="text-gray-600 italic">{exp.company}</p>
              {exp.description && <p className="mt-1 text-gray-700 whitespace-pre-line">{exp.description}</p>}
            </div>
          ))}
        </div>
      )}

      {/* Education */}
      {education.some(e => e.institution || e.degree) && (
        <div className="mb-4">
          <h2 className="text-xs font-bold uppercase tracking-wider border-b border-gray-300 pb-1 mb-2">Education</h2>
          {education.map(edu => (
            <div key={edu.id} className="mb-3">
              <div className="flex justify-between items-baseline">
                <h3 className="font-bold">{edu.degree}{edu.field ? ` in ${edu.field}` : ''}</h3>
                <span className="text-gray-500" style={{ fontSize: '9px' }}>{edu.startDate}{edu.endDate ? ` - ${edu.endDate}` : ''}</span>
              </div>
              <p className="text-gray-600 italic">{edu.institution}</p>
              {edu.description && <p className="mt-1 text-gray-700">{edu.description}</p>}
            </div>
          ))}
        </div>
      )}

      {/* Skills */}
      {skills.length > 0 && (
        <div className="mb-4">
          <h2 className="text-xs font-bold uppercase tracking-wider border-b border-gray-300 pb-1 mb-2">Skills</h2>
          <p className="text-gray-700">{skills.join('  |  ')}</p>
        </div>
      )}

      {/* Projects */}
      {projects.some(p => p.name) && (
        <div className="mb-4">
          <h2 className="text-xs font-bold uppercase tracking-wider border-b border-gray-300 pb-1 mb-2">Projects</h2>
          {projects.map(proj => (
            <div key={proj.id} className="mb-2">
              <div className="flex items-baseline gap-2">
                <h3 className="font-bold">{proj.name}</h3>
                {proj.url && <a className="text-blue-600" style={{ fontSize: '9px' }}>{proj.url}</a>}
              </div>
              {proj.description && <p className="text-gray-700">{proj.description}</p>}
            </div>
          ))}
        </div>
      )}

      {/* Certifications */}
      {certifications.some(c => c.name) && (
        <div className="mb-4">
          <h2 className="text-xs font-bold uppercase tracking-wider border-b border-gray-300 pb-1 mb-2">Certifications</h2>
          {certifications.map(cert => (
            <div key={cert.id} className="flex justify-between items-baseline mb-1">
              <span><span className="font-bold">{cert.name}</span>{cert.issuer ? ` - ${cert.issuer}` : ''}</span>
              {cert.date && <span className="text-gray-500" style={{ fontSize: '9px' }}>{cert.date}</span>}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
